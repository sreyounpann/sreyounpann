//
//  main.cpp
//  M9E2
//
//  Created by Yeow Pann on 31/3/22.
//
#include <iostream>
using namespace std;
int main(){
    int op; //op = oparetion
    int cellcard, smart, metfone;
    float costc,costs,costm,cpm, cpm1;
    cout << "Meeting9 Exercise2\n";
    cout << "==========Display Service==========" << endl;
    cout<<"Press 1 to use Cellcard service.\n"; //if they press 1 it will go to calculate for cellcard.
    cout <<"Press 2 to use Smart service .\n"; //if they press 2 it will go to calculate for smart.
    cout <<"Press 3 to use Metfone service.\n"; //if they press 3 it will go to calculate for metfone.
    cout <<"Choose an Option :"; cin >> op; //let the user input the option

    switch (op) { //if use "switch" you have to take op int to process it.
        case 1:
            cout << "==============================" << endl;
            cout << "Input time your :"; cin >> cellcard; //Time of call : 3min
            costc = 0.30; //Cost 0.30cent per min.
            cpm = costc*cellcard;
            cpm1= cpm/100;

            //cpm is the new integer here.( cpm=cost per min). so costc=0.3 x Cellcard = user input the period of time that they call.
            cout << "You have to charge $ "<<cpm<< " For your service."<< endl;
            break; //so next is you have to bring cpm (or cost per min) use here to show the answer.
        case 2:
            cout << "==============================" << endl;
            cout << "Input time your call :"; cin >> smart; //user input time of call : 3min
            costs = 0.40; //cost 0.40$ per min
            cpm = costs * smart;
            cpm1= cpm/100; //cpm is the new integer here.( cpm=cost per min). so costc=0.40$ x smart (what  user input the period of time that they call).
            cout << "You have to charge $" <<cpm<< " For your service." << endl;
            break;//so next is you have to bring cpm (or cost per min) use here to show the answer.
        case 3:
            cout << "==============================" << endl;
            cout << "Input time of your call:"; cin >>metfone; //Time of call : 3min
            costm = 0.50;//cost 0.40$ per min
            cpm = costm * metfone;
            cpm1= cpm/100;
            //cpm is the new integer here.( cpm=cost per min). so costc=0.50$ x metfone (what  user input the period of time that they call).
            cout << "You have to charge $" << cpm << " for your service." << endl; //so next is you have to bring cpm (or cost per min) use here to show the answer
            break;

        default:cout <<"UNKNOW OPTION" << endl; //for default here is to show the error when user input diff option that we gave. Example : the program only give 3 optione (opt1 opt2 opt3) but they input opt 4 or 5 etc...
            break;
    }
}
