//
//  main.cpp
//  M9E1
//
//  Created by Yeow Pann on 30/3/22.
//
/*ExerciseM9-Ex1
 The user enters a symbol from the keyboard. Determine what a symbol is: letter, number, punctuation mark or something else.
*/
#include <iostream>
using namespace std;
int main(){
    char c;
    cout << "Metting 9 Excersice1" << endl ;
    cout << "===================="<< endl;
    cout << "Input symbol :"; cin >> c; //let the user input whatever char they want.

    if (isalpha(c)) //this is the funtion to use for latter. ex: A-Z.
    {
        cout << "===================="<< endl;
        cout << "It is a letter." << endl; //Print it out if it is isalpha fun.
    }
    else if (isalnum(c))//Ex: this is the funtion to use for  Number only
    {
        cout << "===================="<< endl;
        cout << "It is a number." << endl; //Print it out if it is isalnum fun.
    }

    else if (ispunct(c))//Ex:',",!, (Puncuation)
    {
        cout << "===================="<< endl;
        cout << "It is a Punctuation." << endl;//Print it out if it is ispunct fun.
    }
    else //for fale answer
    {
        cout << "===================="<< endl;
        cout << "It is something else" << endl; //if it is something else like khmer language another language...or something like ¢ £ § ¶ • ª ™ it will print out as something else
    }
}

