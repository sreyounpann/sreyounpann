//
//  main.cpp
//  M9E3
//
//  Created by Yeow Pann on 31/3/22.
/*
Exercise 3.
Vasya works as a programmer and gets $ 50 for every 100 strings of code. For every third delay Vasya is fined $ 20. Implement a menu:
the user enters a desired income of Vasey and a number of delays; count the number of strings of code that he should write;
the user enters a number of strings of code written by Vasya and a desired amount of salary. Calculate how many times Vasya could delay;
the user enters a number of strings of code and a number of delays; determine how much money Vasya will earn and whether it is paid.
 */
#include<iostream>
using namespace std;
int main(){
    int opt;
    int income,code,delay;
    cout << "Meeting9 Exercise3\n";
    cout << "==================================================\n";
    cout << "Press 1 to find number of string Vasya Should write\n"; //first option
    cout << "Press 2 to find delay that Vasya could\n";//second option
    cout << "Press 3 to find How much money Vasya could earn\n";//third option
    cout << "Choose Option :"; cin >> opt;
    switch (opt) {
        case 1:
            cout << "==================================================\n";
            cout << "Input Income desire ($):"; cin >> income; //input income desire($) : 200$
            cout << "==================================================\n";
            cout << "====For every third delay is fined $ 20====\n"; //every third delay -20$
            cout << "Time of Vasya Delay :"; cin >> delay; //perid of delay : 3time = -20$
            code = income/50*100; //200/50*100;
            if (delay>=3) { //if delay bigger than 3
                delay= delay/3*20; //3/3*20=20$
                cout << "==================================================\n";
                cout << "Vasya should write " << code <<" number of string code because he delay so deduct " << delay <<"$" << endl;
            }
            if (delay<3) { //if delay smaller that 3 there is no deduction
                cout << "==================================================\n";
                cout << "Vasya should write " << code <<"lines and no dedubtion of his income" << endl;
            }
            break;
        case 2:
            cout << "==================================================\n";
            cout << "Input number of string code :"; cin >> code; //input number of code : 200 lines

            cout << "You can earn only " << code/2 << "$" << endl; // 200/2=100$
            cout << "Input desire salary ($):"; cin >> income; //input desire salary : 100$
            code = code/2; //200/2=100$
            delay = code - income; //100-100$
            delay = delay*3/20;
            if (delay<0) {
                cout << "ERROR,You need to write more line" << endl;
            }
            else{
            cout << "==================================================\n";
            cout << "Vasya could delay for " << delay << " time" << endl;
            }
            break;
        case 3:
            cout << "==================================================\n";
            cout << "Input number of code :"; cin >> code;
            cout << "Input number of delay :"; cin >> delay;
            income = code/2;
            delay  = delay/3*20;
            income = income - delay;
            cout << "==================================================\n";
            cout << "Vasya will earn $" << income << " from his coding." << endl;
            break;
        default:
            cout << "==================================================\n";
            cout << "ERROR, UNKNOWN OPTION" << endl;
            break;
    }
}
